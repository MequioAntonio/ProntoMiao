--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.5
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: animale; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.animale (
    eta integer NOT NULL,
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    razza character varying(255) NOT NULL,
    sesso character varying(255) NOT NULL,
    specie character varying(255) NOT NULL,
    taglia character varying(255) NOT NULL
);


ALTER TABLE public.animale OWNER TO postgres;

--
-- Name: animale_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.animale_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.animale_seq OWNER TO postgres;

--
-- Name: annuncio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.annuncio (
    id integer NOT NULL,
    id_animale integer NOT NULL,
    id_centro integer NOT NULL,
    descrizione character varying(255) NOT NULL,
    foto_profilo character varying(255) NOT NULL,
    informazioni_mediche character varying(255) NOT NULL,
    titolo character varying(255) NOT NULL
);


ALTER TABLE public.annuncio OWNER TO postgres;

--
-- Name: annuncio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.annuncio_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.annuncio_seq OWNER TO postgres;

--
-- Name: centro_adozioni; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.centro_adozioni (
    id integer NOT NULL,
    descrizione character varying(255) NOT NULL,
    eventi character varying(255),
    indirizzo character varying(255) NOT NULL,
    nome character varying(255) NOT NULL,
    orari character varying(255) NOT NULL
);


ALTER TABLE public.centro_adozioni OWNER TO postgres;

--
-- Name: privato; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.privato (
    id integer NOT NULL,
    codice_fiscale character varying(255) NOT NULL,
    cognome character varying(255) NOT NULL,
    condizioni_abitative character varying(255),
    indirizzo character varying(255),
    informazioni_aggiuntive character varying(255),
    nome character varying(255) NOT NULL,
    preferenze character varying(255),
    telefono character varying(255)
);


ALTER TABLE public.privato OWNER TO postgres;

--
-- Name: recensione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensione (
    id integer NOT NULL,
    id_centro integer,
    id_utente integer,
    voto integer NOT NULL,
    descrizione character varying(255)
);


ALTER TABLE public.recensione OWNER TO postgres;

--
-- Name: recensione_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recensione_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recensione_seq OWNER TO postgres;

--
-- Name: richiesta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.richiesta (
    id integer NOT NULL,
    id_annuncio integer NOT NULL,
    id_utente integer NOT NULL,
    stato integer NOT NULL,
    data timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.richiesta OWNER TO postgres;

--
-- Name: richiesta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.richiesta_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.richiesta_seq OWNER TO postgres;

--
-- Name: segnalazione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.segnalazione (
    id integer NOT NULL,
    id_centro integer,
    id_privato integer NOT NULL,
    descrizione character varying(255) NOT NULL,
    indirizzo character varying(255) NOT NULL,
    titolo character varying(255) NOT NULL
);


ALTER TABLE public.segnalazione OWNER TO postgres;

--
-- Name: segnalazione_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.segnalazione_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.segnalazione_seq OWNER TO postgres;

--
-- Name: utente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utente (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL
);


ALTER TABLE public.utente OWNER TO postgres;

--
-- Name: utente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.utente_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.utente_seq OWNER TO postgres;

--
-- Data for Name: animale; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.animale (eta, id, nome, razza, sesso, specie, taglia) FROM stdin;
\.
COPY public.animale (eta, id, nome, razza, sesso, specie, taglia) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: annuncio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.annuncio (id, id_animale, id_centro, descrizione, foto_profilo, informazioni_mediche, titolo) FROM stdin;
\.
COPY public.annuncio (id, id_animale, id_centro, descrizione, foto_profilo, informazioni_mediche, titolo) FROM '$$PATH$$/3410.dat';

--
-- Data for Name: centro_adozioni; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.centro_adozioni (id, descrizione, eventi, indirizzo, nome, orari) FROM stdin;
\.
COPY public.centro_adozioni (id, descrizione, eventi, indirizzo, nome, orari) FROM '$$PATH$$/3411.dat';

--
-- Data for Name: privato; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.privato (id, codice_fiscale, cognome, condizioni_abitative, indirizzo, informazioni_aggiuntive, nome, preferenze, telefono) FROM stdin;
\.
COPY public.privato (id, codice_fiscale, cognome, condizioni_abitative, indirizzo, informazioni_aggiuntive, nome, preferenze, telefono) FROM '$$PATH$$/3412.dat';

--
-- Data for Name: recensione; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recensione (id, id_centro, id_utente, voto, descrizione) FROM stdin;
\.
COPY public.recensione (id, id_centro, id_utente, voto, descrizione) FROM '$$PATH$$/3413.dat';

--
-- Data for Name: richiesta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.richiesta (id, id_annuncio, id_utente, stato, data) FROM stdin;
\.
COPY public.richiesta (id, id_annuncio, id_utente, stato, data) FROM '$$PATH$$/3414.dat';

--
-- Data for Name: segnalazione; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.segnalazione (id, id_centro, id_privato, descrizione, indirizzo, titolo) FROM stdin;
\.
COPY public.segnalazione (id, id_centro, id_privato, descrizione, indirizzo, titolo) FROM '$$PATH$$/3415.dat';

--
-- Data for Name: utente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utente (id, email, password) FROM stdin;
\.
COPY public.utente (id, email, password) FROM '$$PATH$$/3416.dat';

--
-- Name: animale_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.animale_seq', 101, true);


--
-- Name: annuncio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.annuncio_seq', 751, true);


--
-- Name: recensione_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recensione_seq', 101, true);


--
-- Name: richiesta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.richiesta_seq', 201, true);


--
-- Name: segnalazione_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.segnalazione_seq', 251, true);


--
-- Name: utente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.utente_seq', 1851, true);


--
-- Name: animale animale_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.animale
    ADD CONSTRAINT animale_pkey PRIMARY KEY (id);


--
-- Name: annuncio annuncio_id_animale_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annuncio
    ADD CONSTRAINT annuncio_id_animale_key UNIQUE (id_animale);


--
-- Name: annuncio annuncio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annuncio
    ADD CONSTRAINT annuncio_pkey PRIMARY KEY (id);


--
-- Name: centro_adozioni centro_adozioni_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centro_adozioni
    ADD CONSTRAINT centro_adozioni_pkey PRIMARY KEY (id);


--
-- Name: privato privato_codice_fiscale_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privato
    ADD CONSTRAINT privato_codice_fiscale_key UNIQUE (codice_fiscale);


--
-- Name: privato privato_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privato
    ADD CONSTRAINT privato_pkey PRIMARY KEY (id);


--
-- Name: recensione recensione_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_pkey PRIMARY KEY (id);


--
-- Name: richiesta richiesta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.richiesta
    ADD CONSTRAINT richiesta_pkey PRIMARY KEY (id);


--
-- Name: segnalazione segnalazione_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segnalazione
    ADD CONSTRAINT segnalazione_pkey PRIMARY KEY (id);


--
-- Name: utente utente_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_email_key UNIQUE (email);


--
-- Name: utente utente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_pkey PRIMARY KEY (id);


--
-- Name: centro_adozioni fk54796eylqx4iwd3yq3wyfncsn; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centro_adozioni
    ADD CONSTRAINT fk54796eylqx4iwd3yq3wyfncsn FOREIGN KEY (id) REFERENCES public.utente(id);


--
-- Name: richiesta fk8he75jm8myik2dg625p1sml7l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.richiesta
    ADD CONSTRAINT fk8he75jm8myik2dg625p1sml7l FOREIGN KEY (id_utente) REFERENCES public.privato(id);


--
-- Name: annuncio fk8lvbpkc10cjgbrbouksa9v6l4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annuncio
    ADD CONSTRAINT fk8lvbpkc10cjgbrbouksa9v6l4 FOREIGN KEY (id_centro) REFERENCES public.centro_adozioni(id);


--
-- Name: privato fk9o7e6km9qa08qyynywqjf3w95; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privato
    ADD CONSTRAINT fk9o7e6km9qa08qyynywqjf3w95 FOREIGN KEY (id) REFERENCES public.utente(id);


--
-- Name: annuncio fkbr89wqwrxsswydfnwfonrlf7i; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annuncio
    ADD CONSTRAINT fkbr89wqwrxsswydfnwfonrlf7i FOREIGN KEY (id_animale) REFERENCES public.animale(id);


--
-- Name: recensione fkeitpc1g1jkij2yn1f0fteatjt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT fkeitpc1g1jkij2yn1f0fteatjt FOREIGN KEY (id_centro) REFERENCES public.centro_adozioni(id);


--
-- Name: segnalazione fkgdma3d8ci6b2t6ph737ytgvbi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segnalazione
    ADD CONSTRAINT fkgdma3d8ci6b2t6ph737ytgvbi FOREIGN KEY (id_privato) REFERENCES public.privato(id);


--
-- Name: recensione fkk808uyuc8yvkg27rdxp5vdmae; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT fkk808uyuc8yvkg27rdxp5vdmae FOREIGN KEY (id_utente) REFERENCES public.privato(id);


--
-- Name: segnalazione fkmacb6djusyim5et6ydaoya03j; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segnalazione
    ADD CONSTRAINT fkmacb6djusyim5et6ydaoya03j FOREIGN KEY (id_centro) REFERENCES public.centro_adozioni(id);


--
-- Name: richiesta fknauw1ep41nppr12qnp0xncrax; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.richiesta
    ADD CONSTRAINT fknauw1ep41nppr12qnp0xncrax FOREIGN KEY (id_annuncio) REFERENCES public.annuncio(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

